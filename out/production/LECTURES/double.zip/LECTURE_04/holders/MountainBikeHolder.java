package LECTURE_04.holders;

import LECTURE_04.MountainBike;
import LECTURE_04.services.Basicservice;

/**
 * Created by ladislav on 17/03/17.
 */
public class MountainBikeHolder extends BicycleHolder {
    public MountainBikeHolder(MountainBike bicycle) {
        super(bicycle);
    }
}
