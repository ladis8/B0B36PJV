package LECTURE_04.holders;

import LECTURE_04.Bicycle;

/**
 * Created by ladislav on 17/03/17.
 */
public class BicycleHolder {


    public BicycleHolder(Bicycle bicycle) {
        this.bicycle = bicycle;
    }

    public Bicycle bicycle;


}
