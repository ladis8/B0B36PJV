package LECTURE_04.holders;

import LECTURE_04.Bicycle;

/**
 * Created by ladislav on 17/03/17.
 */
public class RoadBikeHolder extends BicycleHolder {
    public RoadBikeHolder(Bicycle bicycle) {
        super(bicycle);
    }
}
